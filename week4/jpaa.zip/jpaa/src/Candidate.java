import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cand") //OPTIONAL
public class Candidate {
	@Id
	@Column(name="candidateid")
	private int candid;
	private String candname;
	private int candsal;
	private String candAdd;
	
	
	public int getCandid() {
		return candid;
	}
	public void setCandid(int candid) {
		this.candid = candid;
	}
	public String getCandname() {
		return candname;
	}
	public void setCandname(String candname) {
		this.candname = candname;
	}
	public int getCandsal() {
		return candsal;
	}
	public void setCandsal(int candsal) {
		this.candsal = candsal;
	}
	public String getCandAdd() {
		return candAdd;
	}
	public void setCandAdd(String candAdd) {
		this.candAdd = candAdd;
	}
	
	public Candidate() {
		// TODO Auto-generated constructor stub
	}
	public Candidate(int candid, String candname, int candsal, String candAdd) {
		super();
		this.candid = candid;
		this.candname = candname;
		this.candsal = candsal;
		this.candAdd = candAdd;
	}
	@Override
	public String toString() {
		return "Candidate [candid=" + candid + ", candname=" + candname + ", candsal=" + candsal + ", candAdd=" + candAdd + "]";
	}
	

}