import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
	
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("sathya");
		//BRIING ALLL PROPERTIES OF SATYA FROM PRESISTENCE
		
		EntityManager entity=factory.createEntityManager(); 
		
		//PROPERTIES OF ENTITY MANGER USED TO ENTER DTA ANF FOR QUERY//persist()-->save or insert, merge()-->update, remove()-->delte, find()==>selct fetch //ALL ARE DML OPERATIONS
		
		Candidate cand= new Candidate(45, "aj", 10, "jha");
		
		entity.getTransaction().begin();
		
		entity.persist(cand);
		
		
		
		
		entity.getTransaction().commit();
		
	}

}