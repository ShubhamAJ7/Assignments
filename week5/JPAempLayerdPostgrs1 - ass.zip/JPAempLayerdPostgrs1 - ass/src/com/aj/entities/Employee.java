package com.aj.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="canlayerd")
public class Candidate {
	
	@Id
	private int cid;
	@Column(length=15)
	private String cname;
	private int csal;
	@Column(length=15)
	private String cadd;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCsal() {
		return csal;
	}
	public void setCsal(int csal) {
		this.csal = csal;
	}
	public String getCadd() {
		return cadd;
	}
	public void setCadd(String cadd) {
		this.cadd = cadd;
	}
	
	public Candidate() {
		// TODO Auto-generated constructor stub
	}
	public Candidate(int cid, String cname, int csal, String cadd) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.csal = csal;
		this.cadd = cadd;
	}
	@Override
	public String toString() {
		return "Candidate [cid=" + cid + ", cname=" + cname + ", csal=" + csal + ", cadd=" + cadd + "]";
	}
	
	

}
