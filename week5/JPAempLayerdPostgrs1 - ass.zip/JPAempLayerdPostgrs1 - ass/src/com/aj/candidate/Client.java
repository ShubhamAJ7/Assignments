package com.aj.candidate;

import com.aj.entities.Candidate;
import com.aj.service.CandidateService;
import com.aj.service.CandidateServiceImpl;

public class Candidate {

	public static void main(String[] args) {
		
		CandidateService service= new CandidateServiceImpl();
		
		Candidate candidate= new Candidate(7, "raja", 58258, "Antartica");
//		
	service.addCandidate(candidate);
	
		
		//added one record to the table
		
		candidate=service.findCandidateById(111);
		System.out.println("id:" +candidate.getCid());
		System.out.println("name :"+candidate.getCname());
		System.out.println("salary :"+candidate.getCsal());
		

		
	}
}
