package com.aj.dao;

import com.aj.entities.Candidate;

public interface CandidateDao {
	
	Candidate getCandidateById(int id);
	
	void addCandidate(Candidate candidate);
	
	void updateCandidate(Candidate candidate);
	
	void deleteCandidate(Candidate candidate);
	
	void commitTransaction();
	
	void beginTransaction();
	
	

}
