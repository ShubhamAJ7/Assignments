package com.aj.dao;

import javax.persistence.EntityManager;

import com.aj.entities.Candidate;

public class CandidateDaoImpl implements CandidateDao {

	private EntityManager entityManager;

	public CandidateDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public Candidate getCandidateById(int id) {
		Candidate candidate = entityManager.find(Candidate.class, id);
		return candidate;
	}

	@Override
	public void addCandidate(Candidate candidate) {
	
		entityManager.persist(candidate);
		
	}

	@Override
	public void updateCandidate(Candidate candidate) {
		entityManager.merge(candidate);

	}

	@Override
	public void deleteCandidate(Candidate candidate) {
		entityManager.remove(candidate);

	}

	@Override
	public void commitTransaction() {
	entityManager.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
	entityManager.getTransaction().begin();
	}

}
