package com.kt.service;

import com.kt.entities.Candidate;

public interface CandidateService {
	
	void addCandidate(Candidate candidate);
	
	void updateCandidate(Candidate candidate);
	
	void deleteCandidate(Candidate candidate);
	
	Candidate findCandidateById(int id);

}
