package com.aj.service;

import com.aj.dao.CandidateDao;
import com.aj.dao.CandidateDaoImpl;
import com.aj.entities.Candidate;


public class CandidateServiceImpl implements CandidateService {

	
	private CandidateDao dao;
	 
	public CandidateServiceImpl()
	{
		dao= new CandidateDaoImpl();
	}
	 
	@Override
	public void addCandidate(Candidate candidate) {
		
		   dao.beginTransaction();
            dao.addCandidate(candidate);
            dao.commitTransaction();
		
	}

	@Override
	public void updateCandidate(Candidate candidate) {
		dao.beginTransaction();
		dao.updateCandidate(candidate);
		dao.commitTransaction();
		
	}

	@Override
	public void deleteCandidate(Candidate candidate) {
	dao.beginTransaction();
	dao.deleteCandidate(candidate);
	dao.commitTransaction();
		
	}

	@Override
	public Candidate findCandidateById(int id) {
		//no need of transaction, it read option only
		Candidate candidate=dao.getCandidateById(id);
		return candidate;
	}

}
